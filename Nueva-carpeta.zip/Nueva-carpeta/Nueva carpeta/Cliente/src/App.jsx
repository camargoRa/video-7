import { BrowserRouter, Routes, Route } from "react-router-dom";
import RegisterPages from './pages/RegisterPages';
import LoginPages from './pages/LoginPages';
import { AuthProvider } from "./context/AuthContext";
import TaskPage from "./pages/TaskPage";
import TaskFormPage from "./pages/TaskFormPage";
import ProfilePage from "./pages/ProfilePage";
import HomePage from "./pages/HomePage";
import ProtectedRouter from "./ProtectedRouter";

function App() {
  return (
    <>
    <AuthProvider>
    <BrowserRouter>
    <Routes>
      <Route path='/' element={<HomePage/>}> </Route>
      <Route path='/login' element={<LoginPages />}> </Route>
      <Route path='register' element={<RegisterPages/>}> </Route>

      <Route element={<ProtectedRouter/>}>
         <Route path='/tasks' element={<TaskPage/>}></Route>
         <Route path='/add-task' element={<TaskFormPage/>}> </Route>
         <Route path='/tasks/:id' element={<TaskFormPage/>}> </Route>
         <Route path='/profile' element={<ProfilePage/>}> </Route>
      </Route>

    </Routes>
    </BrowserRouter> 
    </AuthProvider>
    </>
  )
}

export default App