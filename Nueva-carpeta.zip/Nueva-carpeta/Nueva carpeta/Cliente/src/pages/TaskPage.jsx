import {useAuth} from '../context/AuthContext'

const TaskPage = () => {

    const { user } = useAuth ()
    console.log(user);

    return (
        <div>
            TAKS
        </div>
    )
}

export default TaskPage
 