const ProfilePage = () => {
    return (
        <div></div>
    )
}

export default ProfilePage
 