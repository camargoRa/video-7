import { Router } from "express";
import { getTask, createTaks, updateTask, deleteTask, getTasks } from "../controllers/task.controller.js";
import { requiredAuth } from '../middlewares/tokenvalidation.js';
import { createTaskSchema} from '../schemas/task.schema.js';
import { validateSchema } from "../middlewares/validator.middleware.js";


const router = Router();

router.get('/tasks',requiredAuth ,getTasks)
router.get('/task/:id',requiredAuth, getTask)
router.post('/task',requiredAuth, validateSchema(createTaskSchema) , createTaks)
router.put('/task/:id', requiredAuth, updateTask)
router.delete('/task/:id', requiredAuth, deleteTask)

export default router;