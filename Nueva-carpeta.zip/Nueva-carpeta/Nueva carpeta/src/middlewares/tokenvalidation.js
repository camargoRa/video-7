import  jwt  from "jsonwebtoken";
import { TOKEN_SECRET } from "../config.js";

export const requiredAuth = (req,res,next) => {
    //console.log(req.headers);
    const { token } = req.cookies;
    //console.log(cookies);
    if(!token)
    return res.status(403).json({ messege : "No token, Authorization Denied"});

    jwt.verify(token, TOKEN_SECRET, (err, user ) => {
        if(err) res.status(403).json({ messege: "Invalid Token"});

        req.user = user;
        next();
    })
}